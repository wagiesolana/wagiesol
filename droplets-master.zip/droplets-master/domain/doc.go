// Package domain contains domain entities and core validation rules.
package domain
