// Package rest exposes the features of droplets as REST API. This
// package uses gorilla/mux for routing.
package rest
