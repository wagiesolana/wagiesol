// Package mongo contains any component in the entire project which interfaces
// with MongoDB (e.g. different store implementations).
package mongo
