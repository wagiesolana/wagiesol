// Package web contains MVC style web app.
package web
