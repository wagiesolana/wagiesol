// Package render provides simple and generic functions for rendering
// data structures using different encoding formats.
package render
