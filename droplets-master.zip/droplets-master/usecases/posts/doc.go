// Package posts has usecases around Post domain entity. This includes
// publishing and management of posts.
package posts
