// Package users has usecases around User domain entity. This includes
// user registration, retrieval etc.
package users
